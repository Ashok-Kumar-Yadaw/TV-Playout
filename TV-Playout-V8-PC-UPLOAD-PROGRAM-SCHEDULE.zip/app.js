const $=id=>document.getElementById(id),program=$("program"),preview=$("preview");
let S={chs:[[],[],[],[]],ch:0,i:0,logs:[],schedule:[]},previewI=0,localUrls=[],lastScheduleKey="";
const base=new URL(".",location.href);
function log(x){S.logs.push(new Date().toTimeString().slice(0,8)+" • "+x);S.logs=S.logs.slice(-100);$("log").textContent=S.logs.slice().reverse().join("\n")}
function fmt(n){n=Math.max(0,Math.floor(n||0));return[Math.floor(n/3600),Math.floor(n%3600/60),n%60].map(x=>String(x).padStart(2,"0")).join(":")}
function fileURL(s){return /^blob:|^https?:/.test(s)?s:new URL(s.split("/").map(encodeURIComponent).join("/"),base).href}
function channels(){$("channels").innerHTML=S.chs.map((_,i)=>`<button class="ch ${i===S.ch?"active":""}" onclick="switchCh(${i})">CH ${i+1}</button>`).join("")}
function switchCh(i){S.ch=i;S.i=0;render();channels();updateScheduleSelect();log("CH "+(i+1))}
function render(){let l=S.chs[S.ch];$("count").textContent=l.length+" EVENTS";$("playlist").innerHTML=l.map((x,i)=>`<div class="item ${i===S.i?"active":""}"><b>${i+1}</b><span>${x.title}<small>${x.local?"PC FILE":"GITHUB • "+x.src}</small></span><button onclick="previewItem(${i})">PREVIEW</button><button onclick="take(${i})">TAKE</button></div>`).join("")||'<p class="hint">Playlist खाली है। PC files select करें या GitHub scan करें।</p>';$("now").textContent=l[S.i]?.title||"—";$("next").textContent=(l[S.i+1]||l[0])?.title||"—";$("chbug").textContent="CH "+(S.ch+1);$("log").textContent=S.logs.slice().reverse().join("\n")}
function previewItem(i){let x=S.chs[S.ch][i];if(!x)return;previewI=i;preview.src=fileURL(x.src);preview.load();$("previewTitle").textContent=x.title;preview.play().catch(()=>{});log("PREVIEW • "+x.title)}
function take(i){let x=S.chs[S.ch][i];if(!x)return;S.i=i;program.src=fileURL(x.src);program.load();render();program.play().catch(()=>{$("state").textContent="PRESS PLAY"});log("TAKE • "+x.title)}
$("addFiles").onclick=()=>{let fs=[...$("files").files];if(!fs.length){alert("पहले video files चुनें");return}fs.forEach(f=>{let u=URL.createObjectURL(f);localUrls.push(u);S.chs[S.ch].push({src:u,title:f.name,local:true})});render();updateScheduleSelect();$("files").value="";log(fs.length+" PC video(s) added")};
$("clearLocal").onclick=()=>{S.chs=S.chs.map(l=>l.filter(x=>!x.local));localUrls.forEach(u=>URL.revokeObjectURL(u));localUrls=[];S.i=0;render();log("PC FILES CLEARED")};
$("take").onclick=()=>take(previewI);$("play").onclick=()=>program.play().catch(()=>{});$("pause").onclick=()=>program.pause();$("stop").onclick=()=>{program.pause();program.currentTime=0;log("STOP")};
$("nextBtn").onclick=()=>{let l=S.chs[S.ch];if(!l.length)return;if(S.i+1<l.length)S.i++;else if($("loop").checked)S.i=0;else return;take(S.i)};
program.onloadedmetadata=()=>{$("state").textContent="READY"};program.onplaying=()=>{$("state").textContent="PLAYING"};program.ontimeupdate=()=>{$("remain").textContent=fmt(program.duration-program.currentTime)};program.onended=()=>{if($("auto").checked||$("loop").checked)$("nextBtn").click()};program.onerror=()=>{let x=S.chs[S.ch][S.i];$("state").textContent="MEDIA ERROR";log("MEDIA ERROR • "+(x?.title||"unknown"))};
async function scan(){let status=$("scanStatus");status.textContent=" SCANNING...";try{let r=await fetch("https://api.github.com/repos/Ashok-Kumar-Yadaw/TV-Playout/contents/videos?ref=main",{cache:"no-store"});if(!r.ok)throw Error("GitHub API "+r.status);let d=await r.json(),mp4=d.filter(x=>x.type==="file"&&/\.mp4$/i.test(x.name));S.chs[S.ch].push(...mp4.map(x=>({src:"videos/"+x.name,title:x.name,local:false})));render();updateScheduleSelect();status.textContent=" "+mp4.length+" MP4 FOUND";log("GitHub scan • "+mp4.length+" MP4") }catch(e){status.textContent=" ERROR";log("GitHub scan error • "+e.message)}}
$("scan").onclick=scan;

function updateScheduleSelect(){
  const sel=$("schedItem"), ch=+$("schedChannel").value, old=sel.value;
  sel.innerHTML='<option value="">Select video</option>'+S.chs[ch].map((x,i)=>`<option value="${i}">${i+1}. ${x.title}</option>`).join("");
  if(old && S.chs[ch][+old]) sel.value=old;
}
function renderSchedule(){
  const list=$("scheduleList");
  S.schedule.sort((a,b)=>a.time.localeCompare(b.time));
  $("scheduleStatus").textContent=S.schedule.length+" SCHEDULED";
  list.innerHTML=S.schedule.map((s,i)=>`<div class="scheditem"><b>${s.time}</b><b>CH ${s.ch+1}</b><span>${s.title}<small> ${s.enabled?"AUTO START":"MANUAL"}</small></span><button onclick="runSchedule(${i})">RUN</button><button onclick="deleteSchedule(${i})">DELETE</button></div>`).join("") || '<p class="hint">अभी कोई schedule नहीं है।</p>';
}
function addSchedule(){
  const time=$("schedTime").value, ch=+$("schedChannel").value, item=+$("schedItem").value;
  if(!time || $("schedItem").value===""){alert("Time और video चुनें");return}
  const x=S.chs[ch][item]; if(!x)return;
  S.schedule.push({time,ch,item,title:x.title,enabled:$("schedAuto").checked});
  renderSchedule();updateScheduleSelect();log("SCHEDULE ADD • "+time+" • CH "+(ch+1)+" • "+x.title);
}
function deleteSchedule(i){let s=S.schedule[i];S.schedule.splice(i,1);renderSchedule();log("SCHEDULE DELETE • "+s.time+" • "+s.title)}
function runSchedule(i){let s=S.schedule[i];S.ch=s.ch;S.i=s.item;channels();take(s.item);log("SCHEDULE RUN • "+s.time+" • CH "+(s.ch+1))}
$("schedChannel").onchange=updateScheduleSelect;
$("addSchedule").onclick=addSchedule;
$("clearSchedule").onclick=()=>{S.schedule=[];renderSchedule();log("SCHEDULE CLEARED")};

function checkSchedule(){
  const now=new Date(), t=now.toTimeString().slice(0,5), key=now.toDateString()+" "+t;
  if(key===lastScheduleKey)return;
  lastScheduleKey=key;
  S.schedule.forEach((s,i)=>{if(s.enabled&&s.time===t)runSchedule(i)});
}
function clock(){$("clock").textContent=new Date().toTimeString().slice(0,8);checkSchedule()}setInterval(clock,1000);clock();channels();render();updateScheduleSelect();renderSchedule();