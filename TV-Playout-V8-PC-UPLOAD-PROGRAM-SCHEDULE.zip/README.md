# TV Playout V7 - PC Upload

## PC से video चलाना
1. Website खोलें।
2. **PC VIDEO UPLOAD** में `Choose File` पर click करें।
3. एक या कई MP4 files select करें।
4. **ADD TO PLAYLIST** दबाएँ।
5. PREVIEW / TAKE / PLAY / NEXT / AUTO NEXT / LOOP इस्तेमाल करें।

### महत्वपूर्ण
PC upload browser-local है। इससे file GitHub repository में upload नहीं होती। Page बंद/refresh होने पर local object URLs खत्म हो सकते हैं; files दोबारा चुनें।

GitHub videos के लिए `SCAN GITHUB /videos` इस्तेमाल करें।

यह version local files के लिए browser का native video playback इस्तेमाल करता है; file को server पर upload या convert नहीं करता।


## Program Schedule V8
- 4 channels के लिए अलग schedule
- `HH:MM` time पर video auto-start
- Channel + video चुनकर `ADD SCHEDULE`
- `AUTO START` बंद करने पर schedule केवल list में रहेगा; `RUN` से manual start किया जा सकता है
- Browser के local time के अनुसार schedule चलता है
- Schedule page/browser खुला रहने पर चलता है
- Multiple events allowed
